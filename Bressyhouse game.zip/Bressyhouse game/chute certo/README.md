Um jogo bem intuitivo de memória com o tema de rick and morty! 1- Insira seu nome de jogador e dê o play!! 2- Se divirta! :)
